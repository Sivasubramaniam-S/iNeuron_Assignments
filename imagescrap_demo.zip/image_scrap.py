import requests
import re
import os

user = input("Enter keyword for image : ")
user_Agent = {"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"}
url = f"https://www.google.com/search?q={user}&tbm=isch&ved=2ahUKEwi-7--tj_3vAhXLO7cAHQoCAj0Q2-cCegQIABAA&oq={user}&gs_lcp=CgNpbWcQAzIECAAQQzIHCAAQsQMQQzIECAAQQzIHCAAQsQMQQzIHCAAQsQMQQzIECAAQQzIHCAAQsQMQQzIHCAAQsQMQQzIHCAAQsQMQQzIECAAQQzoFCAAQsQNQx5wJWJ2nCWDQqAloAHAAeAGAAeUBiAGGBZIBBTAuMy4xmAEAoAEBqgELZ3dzLXdpei1pbWfAAQE&sclient=img&ei=T412YP6LJcv33LUPioSI6AM&bih=717&biw=1294&hl=en"


#_["https://www.heart.org/-/media/images/healthy-living/healthy-lifestyle/man_relaxing_in_nature.jpg",450,800]
pattern = "\[\"https://.*\.jpg\",[0-9]+,[0-9]+\]"
pattern1 = "\[\"https://.*\.jpeg\",[0-9]+,[0-9]+\]"

response = requests.get(url = url,headers = user_Agent).text

img_tag = re.findall(pattern1,response)
images = re.findall(pattern,response)
#print(images)
for e in img_tag:
    images.append(e)

print(f"Total no. of images : {len(images)}")
No_of_images = int(input("Enter number of images required : "))

#Add your preferred File Directory below before executing

directory = os.path.join('File Directory'+'\\'+user)
if images:
    if not os.path.exists(directory):
        os.mkdir(directory)
        os.chdir(directory)
    else:
        os.chdir(directory)


    for Num,tags in enumerate(images[:No_of_images]):
        img_url = eval(tags)[0]
        content = requests.get(img_url).content
        img_name = img_url.split('/')[-1]

        with open(img_name,"wb") as f:
            f.write(content)
            print(f"{Num+1} : {img_name} added successfully")



