from flask import Flask, render_template, request,jsonify
from flask_cors import CORS,cross_origin
from bs4 import BeautifulSoup as Bs
from urllib.request import urlopen as ureq
import requests


app = Flask(__name__)

@app.route('/',methods=['GET'])  # route to display the home page
@cross_origin()
def homePage():
    return render_template("index.html")

@app.route('/review',methods=['POST','GET']) # route to show the review comments in a web UI
@cross_origin()
def index():

    if request.method == 'POST':

        try:
            Keyword = request.form['content'].replace(" ","")
            site_url = "https://www.shopclues.com/search?q=" + Keyword
            '''site_read = ureq(site_url)
            site_page = site_read.read()
            site_read.close()'''
            site_page = requests.get(site_url).text
            #site_page.encoding = 'utf-8'
            soup = Bs(site_page,'html.parser')
            box1 = soup.find("div",id = "product_list")
            box2 = box1.find_all("div",class_ = "row")
            #box3 = box2.find_all("div",class_ = "column col3 search_blocks")
            #box3 = box2[0].find_all("div",class_ = "column col3 search_blocks")

            Prod_Details = []
            for num in range(len(box2)):
                for content in box2[num].find_all("div",class_ = "column col3 search_blocks"):
                    try:
                       url = content.a['href']

                    except:
                        url = "No Url"

                    try:
                        prod_desc = content.a.h2.text

                    except:
                        prod_desc = "No_desc"

                    try:
                        Disc_Price = content.a.find("span",class_ = "p_price").text.replace(" ","")

                    except:
                        Disc_Price = "No price listed"

                    try:
                        DiscountRate = content.a.find("span",class_ = "prd_discount").text

                    except:
                        DiscountRate = "No Discount Rate listed"

                    try:
                        Org_Price = content.a.find("div",class_ = "old_prices").find("span",class_ = "p_price").text.replace(" ","")

                    except:
                        Org_Price = "No Price listed"


                    my_dict = {"Description":prod_desc,"Price":Disc_Price,"OldPrice":Org_Price,"Discount":DiscountRate,"Product_URL":url}
                    Prod_Details.append(my_dict)
            return render_template("results.html", Prod_Details = Prod_Details[0:(len(Prod_Details))-1])
        except Exception as e:
            print("The Error occured is : ",e)
            return "Error Occurred"
    else:
        return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
